using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ClassicSnakeGame1
{
    public partial class Form1 : Form
    {
        private List<Point> snake = new List<Point>();
        private Point food;

        private int score = 0;
        private int highScore = 0;

        private int cellSize = 20;
        private int gridWidth = 35;
        private int gridHeight = 30;

        private enum Direction { Up, Down, Left, Right }
        private Direction currentDirection = Direction.Right;
        private Direction nextDirection = Direction.Right;

        private bool isGameOver = false;
        private bool isPaused = false;

        private Random rand = new Random();

        private enum FoodType { Normal, Fast, Slow, Bonus }
        private FoodType currentFoodType;

        private Color snakeColor = Color.Green;
        private Color backgroundColor = Color.Black;

        
        public Form1()
        {
            InitializeComponent();
            KeyPreview = true;
            this.KeyDown += Form1_KeyDown;
        }

        private void StartGame()
        {
            
            snake.Clear();
            score = 0;
            lblScore.Text = "Score: 0";
            isGameOver = false;
            isPaused = false;

            // Snake starting position
            snake.Add(new Point(5, 10));
            snake.Add(new Point(4, 10));
            snake.Add(new Point(3, 10));

            currentDirection = Direction.Right;
            nextDirection = Direction.Right;

            GenerateFood();

            gamePanel.BackColor = backgroundColor;
            gameTimer.Interval = 120;
            gameTimer.Start();
            gamePanel.Invalidate();
        }

        private void GenerateFood()
        {
            while (true)
            {
                Point p = new Point(rand.Next(0, gridWidth), rand.Next(0, gridHeight));
                if (!snake.Contains(p))
                {
                    food = p;
                    break;
                }
            }

            int chance = rand.Next(0, 100);
            if (chance < 70) currentFoodType = FoodType.Normal;
            else if (chance < 85) currentFoodType = FoodType.Fast;
            else if (chance < 95) currentFoodType = FoodType.Slow;
            else currentFoodType = FoodType.Bonus;
        }

        private void GameLoop()
        {
            if (isGameOver || isPaused) return;

            currentDirection = nextDirection;

            Point head = snake[0];
            Point newHead = head;

            switch (currentDirection)
            {
                case Direction.Up: newHead = new Point(head.X, head.Y - 1); break;
                case Direction.Down: newHead = new Point(head.X, head.Y + 1); break;
                case Direction.Left: newHead = new Point(head.X - 1, head.Y); break;
                case Direction.Right: newHead = new Point(head.X + 1, head.Y); break;
            }

            if (newHead.X < 0 || newHead.X >= gridWidth || newHead.Y < 0 || newHead.Y >= gridHeight || snake.Contains(newHead))
            {
                GameOver();
                return;
            }

            snake.Insert(0, newHead);

            if (newHead == food)
            {
                switch (currentFoodType)
                {
                    case FoodType.Normal: score += 10; break;
                    case FoodType.Fast: score += 20; gameTimer.Interval = Math.Max(20, gameTimer.Interval - 20); break;
                    case FoodType.Slow: score += 5; gameTimer.Interval += 20; break;
                    case FoodType.Bonus: score += 50; break;
                }

                if (score > highScore) highScore = score;
                lblScore.Text = "Score: " + score;
                lblHighScore.Text = "High Score: " + highScore;

             
                GenerateFood();
            }
            else
            {
                snake.RemoveAt(snake.Count - 1);
            }

            // Level system: every 50 points increase speed
            if (score % 50 == 0 && score != 0)
                gameTimer.Interval = Math.Max(30, gameTimer.Interval - 10);

            gamePanel.Invalidate();
        }

        private void GameOver()
        {
          
            isGameOver = true;
            gameTimer.Stop();
          
            MessageBox.Show("Game Over! Your Score: " + score, "Snake Game", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (isGameOver) return;

            if (e.KeyCode == Keys.Up && currentDirection != Direction.Down) nextDirection = Direction.Up;
            else if (e.KeyCode == Keys.Down && currentDirection != Direction.Up) nextDirection = Direction.Down;
            else if (e.KeyCode == Keys.Left && currentDirection != Direction.Right) nextDirection = Direction.Left;
            else if (e.KeyCode == Keys.Right && currentDirection != Direction.Left) nextDirection = Direction.Right;
        }

        private void gamePanel_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // Draw food
            Brush foodBrush = Brushes.Red;
            switch (currentFoodType)
            {
                case FoodType.Fast: foodBrush = Brushes.Yellow; break;
                case FoodType.Slow: foodBrush = Brushes.Blue; break;
                case FoodType.Bonus: foodBrush = Brushes.Purple; break;
            }
            g.FillRectangle(foodBrush, food.X * cellSize, food.Y * cellSize, cellSize, cellSize);

            // Draw snake
            using (SolidBrush snakeBrush = new SolidBrush(snakeColor))
            {
                foreach (Point s in snake)
                    g.FillRectangle(snakeBrush, s.X * cellSize, s.Y * cellSize, cellSize, cellSize);
            }
        }

        private void gameTimer_Tick(object sender, EventArgs e) => GameLoop();

        private void btnStart_Click(object sender, EventArgs e) { StartGame(); this.Focus(); }
        private void btnPause_Click(object sender, EventArgs e)
        {
            if (isGameOver) return;
            isPaused = !isPaused;
            if (isPaused) gameTimer.Stop();
            else gameTimer.Start();
            btnPause.Text = isPaused ? "Resume" : "Pause";
        }
        private void btnRestart_Click(object sender, EventArgs e) { StartGame(); this.Focus(); }

        private void btnSnakeColor_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK) snakeColor = cd.Color;
        }

        private void btnBackgroundColor_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
            {
                backgroundColor = cd.Color;
                gamePanel.BackColor = backgroundColor;
            }
        }

        // Optional arrow buttons
        private void btnUp_Click(object sender, EventArgs e)
        { if (currentDirection != Direction.Down) nextDirection = Direction.Up; }
        private void btnDown_Click(object sender, EventArgs e)
        { if (currentDirection != Direction.Up) nextDirection = Direction.Down; }
        private void btnLeft_Click(object sender, EventArgs e)
        { if (currentDirection != Direction.Right) nextDirection = Direction.Left; }
        private void btnRight_Click(object sender, EventArgs e)
        { if (currentDirection != Direction.Left) nextDirection = Direction.Right; }

        private void lblScore_Click(object sender, EventArgs e)
        {

        }
    }
}