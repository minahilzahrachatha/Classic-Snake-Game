﻿namespace ClassicSnakeGame1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel gamePanel;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblHighScore;
        private System.Windows.Forms.Button btnStart, btnPause, btnRestart;
        private System.Windows.Forms.Button btnSnakeColor, btnBackgroundColor;
        private System.Windows.Forms.Button btnUp, btnDown, btnLeft, btnRight;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            gamePanel = new Panel();
            gameTimer = new System.Windows.Forms.Timer(components);
            lblScore = new Label();
            lblHighScore = new Label();
            btnStart = new Button();
            btnPause = new Button();
            btnRestart = new Button();
            btnSnakeColor = new Button();
            btnBackgroundColor = new Button();
            btnUp = new Button();
            btnDown = new Button();
            btnLeft = new Button();
            btnRight = new Button();
            SuspendLayout();
            // 
            // gamePanel
            // 
            gamePanel.BackColor = Color.Tan;
            gamePanel.Location = new Point(40, 12);
            gamePanel.Name = "gamePanel";
            gamePanel.Size = new Size(700, 600);
            gamePanel.TabIndex = 0;
            gamePanel.Paint += gamePanel_Paint;
            // 
            // gameTimer
            // 
            gameTimer.Interval = 400;
            gameTimer.Tick += gameTimer_Tick;
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblScore.Location = new Point(770, 63);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(87, 28);
            lblScore.TabIndex = 1;
            lblScore.Text = "Score: 0";
            lblScore.Click += lblScore_Click;
            // 
            // lblHighScore
            // 
            lblHighScore.AutoSize = true;
            lblHighScore.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHighScore.Location = new Point(931, 54);
            lblHighScore.Name = "lblHighScore";
            lblHighScore.Size = new Size(138, 28);
            lblHighScore.TabIndex = 2;
            lblHighScore.Text = "High Score: 0";
            // 
            // btnStart
            // 
            btnStart.BackColor = Color.LightSeaGreen;
            btnStart.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnStart.Location = new Point(862, 158);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(120, 40);
            btnStart.TabIndex = 3;
            btnStart.Text = "Start";
            btnStart.UseVisualStyleBackColor = false;
            btnStart.Click += btnStart_Click;
            // 
            // btnPause
            // 
            btnPause.BackColor = Color.LightSeaGreen;
            btnPause.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPause.Location = new Point(862, 228);
            btnPause.Name = "btnPause";
            btnPause.Size = new Size(120, 40);
            btnPause.TabIndex = 4;
            btnPause.Text = "Pause";
            btnPause.UseVisualStyleBackColor = false;
            btnPause.Click += btnPause_Click;
            // 
            // btnRestart
            // 
            btnRestart.BackColor = Color.LightSeaGreen;
            btnRestart.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRestart.Location = new Point(862, 294);
            btnRestart.Name = "btnRestart";
            btnRestart.Size = new Size(120, 40);
            btnRestart.TabIndex = 5;
            btnRestart.Text = "Restart";
            btnRestart.UseVisualStyleBackColor = false;
            btnRestart.Click += btnRestart_Click;
            // 
            // btnSnakeColor
            // 
            btnSnakeColor.BackColor = Color.LightSeaGreen;
            btnSnakeColor.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSnakeColor.Location = new Point(173, 631);
            btnSnakeColor.Name = "btnSnakeColor";
            btnSnakeColor.Size = new Size(170, 47);
            btnSnakeColor.TabIndex = 6;
            btnSnakeColor.Text = "Snake Color";
            btnSnakeColor.UseVisualStyleBackColor = false;
            btnSnakeColor.Click += btnSnakeColor_Click;
            // 
            // btnBackgroundColor
            // 
            btnBackgroundColor.BackColor = Color.LightSeaGreen;
            btnBackgroundColor.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBackgroundColor.Location = new Point(431, 630);
            btnBackgroundColor.Name = "btnBackgroundColor";
            btnBackgroundColor.Size = new Size(172, 49);
            btnBackgroundColor.TabIndex = 7;
            btnBackgroundColor.Text = "Background";
            btnBackgroundColor.UseVisualStyleBackColor = false;
            btnBackgroundColor.Click += btnBackgroundColor_Click;
            // 
            // btnUp
            // 
            btnUp.BackColor = Color.OliveDrab;
            btnUp.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUp.Location = new Point(911, 425);
            btnUp.Name = "btnUp";
            btnUp.Size = new Size(50, 40);
            btnUp.TabIndex = 8;
            btnUp.Text = "↑";
            btnUp.UseVisualStyleBackColor = false;
            btnUp.Click += btnUp_Click;
            // 
            // btnDown
            // 
            btnDown.BackColor = Color.OliveDrab;
            btnDown.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDown.Location = new Point(911, 517);
            btnDown.Name = "btnDown";
            btnDown.Size = new Size(50, 40);
            btnDown.TabIndex = 9;
            btnDown.Text = "↓";
            btnDown.UseVisualStyleBackColor = false;
            btnDown.Click += btnDown_Click;
            // 
            // btnLeft
            // 
            btnLeft.BackColor = Color.OliveDrab;
            btnLeft.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLeft.Location = new Point(862, 471);
            btnLeft.Name = "btnLeft";
            btnLeft.Size = new Size(50, 40);
            btnLeft.TabIndex = 10;
            btnLeft.Text = "←";
            btnLeft.UseVisualStyleBackColor = false;
            btnLeft.Click += btnLeft_Click;
            // 
            // btnRight
            // 
            btnRight.BackColor = Color.OliveDrab;
            btnRight.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRight.Location = new Point(967, 471);
            btnRight.Name = "btnRight";
            btnRight.Size = new Size(50, 40);
            btnRight.TabIndex = 11;
            btnRight.Text = "→";
            btnRight.UseVisualStyleBackColor = false;
            btnRight.Click += btnRight_Click;
            // 
            // Form1
            // 
            BackColor = Color.Cornsilk;
            ClientSize = new Size(1124, 688);
            Controls.Add(gamePanel);
            Controls.Add(lblScore);
            Controls.Add(lblHighScore);
            Controls.Add(btnStart);
            Controls.Add(btnPause);
            Controls.Add(btnRestart);
            Controls.Add(btnSnakeColor);
            Controls.Add(btnBackgroundColor);
            Controls.Add(btnUp);
            Controls.Add(btnDown);
            Controls.Add(btnLeft);
            Controls.Add(btnRight);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            Text = "Snake Game";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}